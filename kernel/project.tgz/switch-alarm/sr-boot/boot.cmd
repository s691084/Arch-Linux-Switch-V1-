echo "=== Arch Linux ARM: loading mojyack kernel ==="
setenv bootargs "root=PARTUUID=d5abfddc-02 rw rootwait panic=10 loglevel=7 fbcon=rotate:3 console=tty0"
setenv kaddr 0x80080000
setenv faddr 0x83000000
setenv ok 0
for d in 1 0; do
  if test ${ok} = 0; then
    if ext4load mmc ${d}:2 ${kaddr} /boot/Image-mojyack; then
      ext4load mmc ${d}:2 ${faddr} /boot/tegra210-nintendo-switch.dtb && setenv ok 1
    fi
  fi
done
if test ${ok} = 1; then
  echo "=== trying booti ==="
  booti ${kaddr} - ${faddr}
fi
# This U-Boot may not have booti: fall back to bootm with a uImage (U-Boot-wrapped kernel)
setenv uaddr 0x88000000
for d in 1 0; do
  if ext4load mmc ${d}:2 ${uaddr} /boot/uImage-mojyack; then
    ext4load mmc ${d}:2 ${faddr} /boot/tegra210-nintendo-switch.dtb
    echo "=== trying bootm ==="
    bootm ${uaddr} - ${faddr}
  fi
done
echo "=== boot failed, restarting in 5 s ==="
sleep 5
reset
