# Arch Linux ARM (mojyack mainline kernel) - Switchroot U-Boot boot script
setenv boot_dir ${prefix}
test -n ${devnum}          || setenv devnum 1
test -n ${distro_bootpart} || setenv distro_bootpart 1
setenv kernload 0xA0000000
setenv fdtraddr 0x8d000000
echo "=== Arch Linux ARM: mojyack kernel from ${boot_dir} (mmc ${devnum}:${distro_bootpart}) ==="
if load mmc ${devnum}:${distro_bootpart} ${kernload} ${boot_dir}/uImage; then echo Kernel loaded
else echo Kernel read failed!; sleep 10; reset; fi
if load mmc ${devnum}:${distro_bootpart} ${fdtraddr} ${boot_dir}/switch.dtb; then echo Device tree loaded
else echo Device tree read failed!; sleep 10; reset; fi
fdt addr ${fdtraddr}
fdt resize 16384
setenv bootargs "root=/dev/mmcblk0p2 rw rootwait panic=10 loglevel=7 fbcon=rotate:3 console=tty0 consoleblank=0 mem_sleep_default=s2idle"
# Pass the Switch's real Bluetooth/Wi-Fi MAC addresses (Hekate provides them) to Linux
if test -n "${device_bt_mac}"; then setenv bootargs "${bootargs} switch.btmac=${device_bt_mac}"; fi
if test -n "${device_wifi_mac}"; then setenv bootargs "${bootargs} switch.wifimac=${device_wifi_mac}"; fi
echo Launching Kernel!
bootm ${kernload} - ${fdtraddr}
echo Failed to launch kernel! Rebooting in 10s..
sleep 10
reset
